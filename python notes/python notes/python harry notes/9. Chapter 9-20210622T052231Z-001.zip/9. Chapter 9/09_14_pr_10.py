filename = "sample.txt"
with open(filename, "w") as f:
    f.write("")